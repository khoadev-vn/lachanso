// ============================================================
// Lá Chắn Số — Background Service Worker (Manifest V3)
// - Auto-check URL khi điều hướng (webNavigation)
// - Gọi API server chấm điểm (URL + text)
// - Danh sách "không bao giờ kiểm tra web này"
// - Context menu chuột phải
// ============================================================

const API_BASE = "https://lachansovn.com";

// Cache kết quả trong phiên (tránh gọi lại API cho cùng URL/text)
const sessionCache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 phút

// Không check các trang nội bộ hoặc web quá quen thuộc
const SKIP_HOSTS = [
  "localhost", "127.0.0.1", "0.0.0.0",
  "chrome.google.com", "chromewebstore.google.com",
  "lachansovn.com"
];

function getHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function shouldSkip(url) {
  if (!url || !url.startsWith("http")) return true;
  const host = getHostname(url);
  if (!host) return true;
  return SKIP_HOSTS.includes(host) || SKIP_HOSTS.some((s) => host.endsWith("." + s));
}

async function getNeverCheckList() {
  const data = await chrome.storage.local.get("neverCheck");
  return data.neverCheck || {};
}

// ---------- Gọi API ----------
async function callApi(path, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 25000);
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function checkUrl(url) {
  const key = `url:${url}`;
  const cached = sessionCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.data;

  let isGambling = false;
  try {
    const dc = await callApi("/api/check-domain", { url });
    isGambling = !!(dc && dc.isGambling);
  } catch {
    // bỏ qua, vẫn chạy analyze-link
  }

  const data = await callApi("/api/analyze-link", { url });
  const result = {
    type: "url",
    url,
    hostname: getHostname(url),
    score: typeof data.score === "number" ? Math.round(data.score) : null,
    reasons: (data.reasons || []).slice(0, 8),
    isGambling: isGambling || !!data.isGambling,
    raw: data
  };
  sessionCache.set(key, { data: result, expiresAt: Date.now() + CACHE_TTL });
  return result;
}

async function checkText(text) {
  const key = `text:${text}`;
  const cached = sessionCache.get(key);
  if (cached && cached.expiresAt > Date.now()) return cached.data;

  const data = await callApi("/api/verify-fast", { text: text.trim().slice(0, 2000) });
  const result = {
    type: "text",
    score: typeof data.score === "number" ? Math.round(data.score) : null,
    verdict: data.verdict || null,
    patterns: (data.vn_fake_patterns || []).slice(0, 6),
    sensationalism: data.sensationalism ? data.sensationalism.level : null,
    raw: data
  };
  sessionCache.set(key, { data: result, expiresAt: Date.now() + CACHE_TTL });
  return result;
}

// ---------- Message từ content script / popup ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "LCS_CHECK_TEXT") {
    checkText(msg.text || "")
      .then((result) => sendResponse({ ok: true, result }))
      .catch((e) => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === "LCS_CHECK_URL") {
    const url = msg.url || "";
    if (shouldSkip(url)) return sendResponse({ ok: true, skipped: true });
    const host = getHostname(url);
    getNeverCheckList().then(async (never) => {
      if (never[host]) return sendResponse({ ok: true, skipped: true });
      try {
        const result = await checkUrl(url);
        sendResponse({ ok: true, result });
      } catch (e) {
        sendResponse({ ok: false, error: e.message });
      }
    });
    return true;
  }

  if (msg.type === "LCS_NEVER_CHECK") {
    addToNeverCheck(msg.hostname).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "LCS_REMOVE_NEVER_CHECK") {
    removeFromNeverCheck(msg.hostname).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "LCS_GET_NEVER_LIST") {
    getNeverCheckList().then((never) => sendResponse({ ok: true, neverCheck: never }));
    return true;
  }
});

async function addToNeverCheck(hostname) {
  if (!hostname) return;
  const never = await getNeverCheckList();
  never[hostname] = Date.now();
  await chrome.storage.local.set({ neverCheck: never });
}

async function removeFromNeverCheck(hostname) {
  if (!hostname) return;
  const never = await getNeverCheckList();
  delete never[hostname];
  await chrome.storage.local.set({ neverCheck: never });
}

// ---------- Context menu ----------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "lcs-check-link",
      title: "Kiểm tra link với Lá Chắn Số",
      contexts: ["link"]
    });
    chrome.contextMenus.create({
      id: "lcs-check-selection",
      title: "Phân tích đoạn văn bản với Lá Chắn Số",
      contexts: ["selection"]
    });
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;

  if (info.menuItemId === "lcs-check-link" && info.linkUrl) {
    checkUrl(info.linkUrl)
      .then((result) => {
        chrome.tabs.sendMessage(tab.id, { type: "LCS_SHOW_URL_RESULT", result }).catch(() => {});
      })
      .catch(() => {});
  }

  if (info.menuItemId === "lcs-check-selection" && info.selectionText) {
    checkText(info.selectionText)
      .then((result) => {
        chrome.tabs.sendMessage(tab.id, {
          type: "LCS_SHOW_TEXT_RESULT",
          result,
          selectionText: info.selectionText
        }).catch(() => {});
      })
      .catch(() => {});
  }
});