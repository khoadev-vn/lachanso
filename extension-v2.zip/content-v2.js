// ============================================================
// Lá Chắn Số — Content Script (bản hoàn toàn mới)
// - Nhận kết quả check URL từ background → overlay / toast
// - Bôi đen text → bubble tròn → click → popup chấm điểm
// - Context menu: hiện popup kết quả
// Dùng Shadow DOM (closed) + CSS nhúng để cách ly với trang web.
// ============================================================

(function () {
  "use strict";

  if (window.__LCS_LOADED__) return;
  window.__LCS_LOADED__ = true;

  const API_LOGO = chrome.runtime.getURL("icons/icon-128.png");
  const currentHost = window.location.hostname.replace(/^www\./, "");

  const CSS = `
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; }

    /* Overlay chặn */
    .lcs-overlay {
      position: fixed; inset: 0; z-index: 2147483646;
      display: flex; align-items: center; justify-content: center;
      background: rgba(0, 0, 0, 0.55); backdrop-filter: blur(3px);
      animation: lcs-fade 0.2s ease;
    }
    @keyframes lcs-fade { from { opacity: 0 } to { opacity: 1 } }

    .lcs-card {
      width: min(440px, calc(100vw - 32px)); max-height: 84vh; overflow-y: auto;
      background: #fff; border-radius: 18px; box-shadow: 0 24px 60px rgba(0,0,0,0.35);
      padding: 22px; color: #111;
      animation: lcs-pop 0.22s cubic-bezier(0.2, 0.9, 0.3, 1.2);
    }
    @keyframes lcs-pop { from { opacity: 0; transform: scale(0.92) translateY(8px) } to { opacity: 1; transform: scale(1) translateY(0) } }

    .lcs-card-head { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
    .lcs-logo { width: 30px; height: 30px; border-radius: 8px; object-fit: cover; }
    .lcs-title { font-size: 16px; font-weight: 700; color: #111; flex: 1; }
    .lcs-close {
      background: none; border: none; cursor: pointer; font-size: 22px; line-height: 1;
      color: #888; padding: 4px 8px; border-radius: 8px;
    }
    .lcs-close:hover { background: #f0f0f0; color: #111; }

    .lcs-host {
      font-size: 13px; color: #666; word-break: break-all; margin-bottom: 12px;
      background: #f5f4f0; border-radius: 10px; padding: 8px 12px;
    }

    .lcs-badge {
      display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px;
      border-radius: 999px; font-size: 13px; font-weight: 700; margin-bottom: 12px;
    }
    .lcs-badge-danger { background: #fee2e2; color: #b91c1c; }
    .lcs-badge-suspicious { background: #fef3c7; color: #b45309; }
    .lcs-badge-safe { background: #d1fae5; color: #047857; }
    .lcs-badge-unknown { background: #e5e7eb; color: #4b5563; }

    .lcs-score-row { display: flex; align-items: center; gap: 16px; margin-bottom: 12px; }
    .lcs-ring { position: relative; width: 84px; height: 84px; flex-shrink: 0; }
    .lcs-ring svg { transform: rotate(-90deg); }
    .lcs-ring-text {
      position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
      font-size: 24px; font-weight: 800;
    }
    .lcs-verdict { font-size: 18px; font-weight: 700; margin-bottom: 2px; }
    .lcs-subtext { font-size: 13px; color: #666; }

    .lcs-reasons { margin: 8px 0 14px; display: flex; flex-direction: column; gap: 8px; }
    .lcs-reason {
      display: flex; gap: 8px; align-items: flex-start; font-size: 13px;
      padding: 8px 12px; border-radius: 10px; background: #fafafa; border: 1px solid #eee;
    }
    .lcs-reason-icon { flex-shrink: 0; margin-top: 1px; }
    .lcs-reason-name { font-weight: 600; color: #111; }
    .lcs-reason-detail { color: #555; margin-top: 1px; }

    .lcs-actions { display: flex; flex-direction: column; gap: 10px; margin-top: 14px; padding-top: 14px; border-top: 1px solid #eee; }
    .lcs-never-wrap {
      display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555;
      cursor: pointer; user-select: none;
    }
    .lcs-never-wrap input { width: 16px; height: 16px; cursor: pointer; }
    .lcs-btn {
      width: 100%; padding: 12px; border: none; border-radius: 12px; font-size: 15px;
      font-weight: 700; cursor: pointer; transition: filter 0.15s, transform 0.1s;
    }
    .lcs-btn:hover { filter: brightness(0.95); }
    .lcs-btn:active { transform: scale(0.98); }
    .lcs-btn-danger { background: #dc2626; color: #fff; }
    .lcs-btn-suspicious { background: #f59e0b; color: #fff; }
    .lcs-btn-safe { background: #059669; color: #fff; }

    .lcs-footnote { margin-top: 10px; font-size: 11px; color: #aaa; text-align: center; }

    /* Icon nổi luôn hiển thị (kéo thả được) */
    .lcs-fab {
      position: fixed; right: 18px; bottom: 18px; z-index: 2147483647;
      width: 48px; height: 48px; border-radius: 50%;
      background: linear-gradient(135deg, #ff8904, #ff5c1a);
      border: 2.5px solid #fff; box-shadow: 0 6px 22px rgba(255, 137, 4, 0.55);
      display: flex; align-items: center; justify-content: center;
      cursor: grab; user-select: none; pointer-events: auto;
      transition: transform 0.15s, box-shadow 0.15s;
    }
    .lcs-fab:hover { transform: scale(1.08); }
    .lcs-fab:active { cursor: grabbing; }
    .lcs-fab img { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; pointer-events: none; }
    .lcs-fab-label {
      position: absolute; right: 58px; top: 50%; transform: translateY(-50%);
      background: rgba(0,0,0,0.78); color: #fff; font-size: 11.5px; font-weight: 600;
      padding: 4px 10px; border-radius: 8px; white-space: nowrap; pointer-events: none;
      opacity: 0; transition: opacity 0.15s;
    }
    .lcs-fab:hover .lcs-fab-label { opacity: 1; }

    /* Toast an toàn (tự ẩn) */
    .lcs-toast {
      position: fixed; top: 18px; right: 18px; z-index: 2147483647;
      animation: lcs-toast-in 0.25s cubic-bezier(0.2, 0.9, 0.3, 1.2);
      pointer-events: none;
    }
    @keyframes lcs-toast-in { from { opacity: 0; transform: translateY(-12px) scale(0.96) } to { opacity: 1; transform: translateY(0) scale(1) } }
    .lcs-toast-inner {
      display: flex; align-items: center; gap: 10px;
      background: #fff; border: 1px solid #d1fae5; border-left: 4px solid #059669;
      border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.18);
      padding: 10px 14px; min-width: 240px; max-width: 340px;
    }
    .lcs-toast-logo { width: 26px; height: 26px; border-radius: 7px; object-fit: cover; }
    .lcs-toast-body { flex: 1; min-width: 0; }
    .lcs-toast-title { font-size: 13.5px; font-weight: 700; color: #047857; }
    .lcs-toast-host { font-size: 11.5px; color: #777; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .lcs-toast-score { font-size: 18px; font-weight: 800; color: #059669; flex-shrink: 0; }

    /* Bubble chọn text */
    .lcs-bubble {
      position: fixed; z-index: 2147483645; width: 34px; height: 34px; border-radius: 50%;
      background: #ff8904; border: 2px solid #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.3);
      display: flex; align-items: center; justify-content: center; cursor: pointer;
      animation: lcs-fade 0.15s ease; transition: transform 0.12s;
    }
    .lcs-bubble:hover { transform: scale(1.1); }
    .lcs-bubble img { width: 20px; height: 20px; border-radius: 4px; object-fit: cover; }

    /* Popup kết quả text */
    .lcs-text-pop {
      position: fixed; z-index: 2147483646; width: min(340px, calc(100vw - 32px));
      background: #fff; border-radius: 14px; box-shadow: 0 14px 40px rgba(0,0,0,0.3);
      padding: 16px; color: #111; animation: lcs-pop 0.2s cubic-bezier(0.2, 0.9, 0.3, 1.2);
    }
    .lcs-pattern-list { display: flex; flex-direction: column; gap: 6px; margin-top: 8px; }
    .lcs-pattern {
      font-size: 12.5px; padding: 7px 10px; border-radius: 8px;
      background: #fafafa; border: 1px solid #eee; color: #444;
    }
    .lcs-snippet {
      font-size: 12px; color: #888; margin-top: 8px;
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
      overflow: hidden; word-break: break-word;
    }
    .lcs-continue { font-size: 13px; color: #777; background: none; border: none; cursor: pointer; text-align: center; padding: 6px; width: 100%; }
    .lcs-continue:hover { color: #111; text-decoration: underline; }
    .lcs-error {
      padding: 14px; background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px;
      color: #b91c1c; font-size: 13px; text-align: center;
    }
    .lcs-loading { display: flex; flex-direction: column; align-items: center; gap: 12px; padding: 24px 0; color: #666; font-size: 14px; }
    .lcs-spinner {
      width: 36px; height: 36px; border: 4px solid #ffd9a8; border-top-color: #ff8904;
      border-radius: 50%; animation: lcs-spin 0.8s linear infinite;
    }
    @keyframes lcs-spin { to { transform: rotate(360deg) } }
  `;

  // ============ Shadow DOM ============
  const hostEl = document.createElement("div");
  hostEl.id = "lcs-host";
  hostEl.style.cssText = "all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;";
  const shadow = hostEl.attachShadow({ mode: "closed" });

  const styleEl = document.createElement("style");
  styleEl.textContent = CSS;
  shadow.appendChild(styleEl);

  (document.documentElement || document.body).appendChild(hostEl);

  // ============ Icon nổi (FAB) ============
  const fabEl = document.createElement("div");
  fabEl.className = "lcs-fab";
  fabEl.style.pointerEvents = "auto";
  const fabImg = document.createElement("img");
  fabImg.src = API_LOGO;
  fabImg.alt = "Lá Chắn Số";
  const fabLabel = document.createElement("span");
  fabLabel.className = "lcs-fab-label";
  fabLabel.textContent = "Kiểm tra trang này";
  fabEl.appendChild(fabImg);
  fabEl.appendChild(fabLabel);
  shadow.appendChild(fabEl);

  // Kéo thả icon nổi
  let fabDragging = false;
  let fabStartX = 0, fabStartY = 0;
  fabEl.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    fabDragging = false;
    fabStartX = e.clientX;
    fabStartY = e.clientY;
    const moveH = (ev) => {
      const dx = ev.clientX - fabStartX;
      const dy = ev.clientY - fabStartY;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) fabDragging = true;
      if (fabDragging) {
        fabEl.style.right = "auto";
        fabEl.style.bottom = "auto";
        fabEl.style.left = Math.max(4, Math.min(window.innerWidth - 52, ev.clientX - 24)) + "px";
        fabEl.style.top = Math.max(4, Math.min(window.innerHeight - 52, ev.clientY - 24)) + "px";
      }
    };
    const upH = () => {
      document.removeEventListener("mousemove", moveH);
      document.removeEventListener("mouseup", upH);
    };
    document.addEventListener("mousemove", moveH);
    document.addEventListener("mouseup", upH);
  });

  // Click icon → chấm điểm trang hiện tại
  fabEl.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();
    if (fabDragging) { fabDragging = false; return; }
    checkCurrentPage();
  });

  async function checkCurrentPage() {
    const url = window.location.href;
    showOverlay({ score: null, hostname: currentHost, url, reasons: [] }, { force: true, loading: true });
    try {
      const resp = await chrome.runtime.sendMessage({ type: "LCS_CHECK_URL", url });
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || "Lỗi máy chủ");
      showOverlay(resp.result, { force: true });
    } catch (err) {
      showOverlay({ score: null, hostname: currentHost, url, reasons: [] }, { force: true, error: err.message });
    }
  }

  // ============ Utilities ============
  function el(tag, className, parent) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (parent) parent.appendChild(node);
    return node;
  }

  function html(inner) {
    const tpl = document.createElement("template");
    tpl.innerHTML = inner.trim();
    return tpl.content.firstElementChild;
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function classify(score) {
    if (score === null || score === undefined) return { level: "unknown", label: "Không xác định" };
    if (score >= 70) return { level: "safe", label: "An toàn" };
    if (score >= 45) return { level: "suspicious", label: "Cần xác minh" };
    return { level: "danger", label: "Nguy hiểm" };
  }

  function ringHtml(score) {
    if (score === null || score === undefined) {
      return '<div class="lcs-ring"><svg width="84" height="84"><circle cx="42" cy="42" r="36" fill="none" stroke="#e5e7eb" stroke-width="8"/><circle cx="42" cy="42" r="36" fill="none" stroke="#9ca3af" stroke-width="8" stroke-dasharray="226" stroke-dashoffset="0"/></svg><div class="lcs-ring-text">?</div></div>';
    }
    const dashArray = 226.2;
    const offset = dashArray * (1 - Math.max(0, Math.min(100, score)) / 100);
    const color = score >= 70 ? "#059669" : score >= 45 ? "#d97706" : "#dc2626";
    return `<div class="lcs-ring"><svg width="84" height="84"><circle cx="42" cy="42" r="36" fill="none" stroke="#e5e7eb" stroke-width="8"/><circle cx="42" cy="42" r="36" fill="none" stroke="${color}" stroke-width="8" stroke-linecap="round" stroke-dasharray="${dashArray}" stroke-dashoffset="${offset}"/></svg><div class="lcs-ring-text" style="color:${color}">${score}</div></div>`;
  }

  function badgeHtml(level) {
    const map = {
      danger: ["🚨 Nguy hiểm", "lcs-badge-danger"],
      suspicious: ["⚠️ Cần xác minh", "lcs-badge-suspicious"],
      safe: ["✅ An toàn", "lcs-badge-safe"],
      unknown: ["❓ Không xác định", "lcs-badge-unknown"]
    };
    const [label, cls] = map[level] || map.unknown;
    return `<span class="lcs-badge ${cls}">${label}</span>`;
  }

  function reasonHtml(r) {
    const status = r.status || "warning";
    const icon = status === "danger" ? "🔴" : status === "success" ? "🟢" : "🟡";
    const cls = status === "danger" ? "lcs-reason-danger" : status === "success" ? "lcs-reason-success" : "lcs-reason-warning";
    return `<div class="lcs-reason ${cls}"><span class="lcs-reason-icon">${icon}</span><div><div class="lcs-reason-name">${escapeHtml(r.name || "")}</div>${r.detail ? `<div class="lcs-reason-detail">${escapeHtml(r.detail)}</div>` : ""}</div></div>`;
  }

  // ============ Overlay / toast URL ============
  let overlayEl = null;
  let toastEl = null;
  let toastTimer = null;
  let lastCheckedUrl = null;

  function removeFromShadow(node) {
    if (node && node.parentNode === shadow) shadow.removeChild(node);
  }

  function closeOverlay() {
    removeFromShadow(overlayEl);
    overlayEl = null;
    hostEl.style.pointerEvents = "none";
  }

  function showSafeToast(result) {
    removeFromShadow(toastEl);
    clearTimeout(toastTimer);
    toastEl = html(`
      <div class="lcs-toast">
        <div class="lcs-toast-inner">
          <img class="lcs-toast-logo" src="${API_LOGO}" alt="Lá Chắn Số" />
          <div class="lcs-toast-body">
            <div class="lcs-toast-title">✓ Trang chính thống / An toàn</div>
            <div class="lcs-toast-host">${escapeHtml(result.hostname || "")}</div>
          </div>
          <span class="lcs-toast-score">${result.score}</span>
        </div>
      </div>`);
    shadow.appendChild(toastEl);
    toastTimer = setTimeout(() => {
      removeFromShadow(toastEl);
      toastEl = null;
    }, 1800);
  }

  function showOverlay(result, opts) {
    opts = opts || {};

    // Trạng thái lỗi (máy chủ không trả kết quả)
    if (opts.error) {
      removeFromShadow(overlayEl);
      const card = el("div", "lcs-card");
      const head = el("div", "lcs-card-head", card);
      const logo = el("img", "lcs-logo", head);
      logo.src = API_LOGO;
      el("div", "lcs-title", head).textContent = "Lá Chắn Số";
      const closeBtn = el("button", "lcs-close", head);
      closeBtn.innerHTML = "&times;";
      closeBtn.title = "Đóng";
      closeBtn.addEventListener("click", () => closeOverlay());
      el("div", "lcs-error", card).textContent = "Không kiểm tra được: " + opts.error;
      const btn = el("button", "lcs-btn", card);
      btn.className = "lcs-btn lcs-btn-safe";
      btn.textContent = "Đóng";
      btn.addEventListener("click", () => closeOverlay());
      const overlay = el("div", "lcs-overlay");
      overlay.appendChild(card);
      overlayEl = overlay;
      shadow.appendChild(overlay);
      hostEl.style.pointerEvents = "auto";
      return;
    }

    // Trạng thái loading (đang gọi máy chủ)
    if (opts.loading) {
      removeFromShadow(overlayEl);
      const card = el("div", "lcs-card");
      const head = el("div", "lcs-card-head", card);
      const logo = el("img", "lcs-logo", head);
      logo.src = API_LOGO;
      el("div", "lcs-title", head).textContent = "Đang chấm điểm trang này...";
      const loading = el("div", "lcs-loading", card);
      el("div", "lcs-spinner", loading);
      el("div", "lcs-footnote", card).textContent = "Điểm do AI của Lá Chắn Số tính tại máy chủ lachansovn.com";
      const overlay = el("div", "lcs-overlay");
      overlay.appendChild(card);
      overlayEl = overlay;
      shadow.appendChild(overlay);
      hostEl.style.pointerEvents = "auto";
      return;
    }

    // An toàn / chính thống → toast tự ẩn, không chặn
    // (trừ khi người dùng chủ động kiểm tra → luôn hiện card chi tiết)
    if (!opts.force && result.score !== null && result.score !== undefined && result.score >= 70 && !result.isGambling) {
      showSafeToast(result);
      return;
    }

    removeFromShadow(overlayEl);

    const cls = classify(result.score);
    const card = el("div", "lcs-card");

    const head = el("div", "lcs-card-head", card);
    const logo = el("img", "lcs-logo", head);
    logo.src = API_LOGO;
    const t = el("div", "lcs-title", head);
    t.textContent = "Lá Chắn Số";
    const closeBtn = el("button", "lcs-close", head);
    closeBtn.innerHTML = "&times;";
    closeBtn.title = "Đóng";
    closeBtn.addEventListener("click", () => closeOverlay());

    const hostLine = el("div", "lcs-host", card);
    hostLine.textContent = result.hostname || result.url || "";

    card.appendChild(html(badgeHtml(cls.level)));

    const scoreRow = el("div", "lcs-score-row", card);
    scoreRow.innerHTML = ringHtml(result.score);
    const vWrap = el("div", null, scoreRow);
    const verdict = el("div", "lcs-verdict", vWrap);
    verdict.textContent = cls.label + (result.score !== null && result.score !== undefined ? ` (${result.score}/100)` : "");
    const sub = el("div", "lcs-subtext", vWrap);
    sub.textContent = result.isGambling
      ? "Tên miền bị gắn cờ cờ bạc / lừa đảo."
      : result.score === null || result.score === undefined
        ? "Chưa lấy được kết quả từ máy chủ."
        : cls.level === "safe"
          ? "Không phát hiện dấu hiệu nguy hiểm rõ rệt."
          : "Hệ thống phát hiện các dấu hiệu đáng ngờ sau đây:";

    if (result.reasons && result.reasons.length > 0) {
      const reasons = el("div", "lcs-reasons", card);
      result.reasons.forEach((r) => reasons.appendChild(html(reasonHtml(r))));
    }

    const actions = el("div", "lcs-actions", card);

    const neverWrap = el("label", "lcs-never-wrap", actions);
    const cb = el("input", null, neverWrap);
    cb.type = "checkbox";
    el("span", null, neverWrap).textContent = "Không bao giờ kiểm tra web này nữa";
    neverWrap.addEventListener("click", (e) => e.stopPropagation());

    const btn = el("button", "lcs-btn", actions);
    if (cls.level === "danger") {
      btn.className = "lcs-btn lcs-btn-danger";
      btn.textContent = "Tôi hiểu rủi ro, tiếp tục vào";
    } else if (cls.level === "suspicious") {
      btn.className = "lcs-btn lcs-btn-suspicious";
      btn.textContent = "Tôi đã xác minh, tiếp tục";
    } else {
      btn.className = "lcs-btn lcs-btn-safe";
      btn.textContent = "Tiếp tục vào trang";
    }

    const footnote = el("div", "lcs-footnote", actions);
    footnote.textContent = "Điểm do AI của Lá Chắn Số chấm tại máy chủ lachansovn.com";

    function doClose() {
      document.removeEventListener("keydown", escHandler, true);
      if (cb.checked) {
        const skipHost = (result.hostname || currentHost).replace(/^www\./, "");
        try { chrome.runtime.sendMessage({ type: "LCS_NEVER_CHECK", hostname: skipHost }).catch(() => {}); } catch {}
      }
      closeOverlay();
    }
    btn.addEventListener("click", doClose);

    const escHandler = (e) => {
      if (e.key === "Escape") { doClose(); document.removeEventListener("keydown", escHandler, true); }
    };
    document.addEventListener("keydown", escHandler, true);

    const overlay = el("div", "lcs-overlay");
    overlay.appendChild(card);
    overlayEl = overlay;
    shadow.appendChild(overlay);
    hostEl.style.pointerEvents = "auto";
  }

  // ============ Bubble + popup text ============
  let bubbleEl = null;
  let textPopEl = null;

  function selectedText() {
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed) return null;
    const t = sel.toString().trim();
    if (t.length < 15 || t.length > 3000) return null;
    return t;
  }

  function selectionRect() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    return sel.getRangeAt(0).getBoundingClientRect();
  }

  function showBubble(rect) {
    removeFromShadow(bubbleEl);
    bubbleEl = el("div", "lcs-bubble");
    bubbleEl.style.pointerEvents = "auto";
    bubbleEl.style.top = Math.max(4, rect.top - 44) + "px";
    bubbleEl.style.left = Math.max(4, rect.right - 34) + "px";
    const img = document.createElement("img");
    img.src = API_LOGO;
    img.alt = "Kiểm tra bằng Lá Chắn Số";
    bubbleEl.title = "Kiểm tra bằng Lá Chắn Số";
    bubbleEl.appendChild(img);
    bubbleEl.addEventListener("click", onBubbleClick);
    shadow.appendChild(bubbleEl);
  }

  function removeBubble() { removeFromShadow(bubbleEl); bubbleEl = null; }
  function removeTextPop() { removeFromShadow(textPopEl); textPopEl = null; }

  function popupPos(rect) {
    if (!rect) return { top: 20, left: 20 };
    let top = rect.bottom + 8;
    let left = rect.left;
    if (top + 260 > window.innerHeight) top = Math.max(8, rect.top - 280);
    if (left + 340 > window.innerWidth) left = Math.max(8, window.innerWidth - 348);
    return { top, left };
  }

  function showTextPopupLoading(rect, text) {
    removeTextPop();
    const pop = el("div", "lcs-text-pop");
    const pos = popupPos(rect);
    pop.style.top = pos.top + "px";
    pop.style.left = pos.left + "px";
    const head = el("div", "lcs-card-head", pop);
    const logo = el("img", "lcs-logo", head);
    logo.src = API_LOGO;
    el("div", "lcs-title", head).textContent = "Đang chấm điểm...";
    const loading = el("div", "lcs-loading", pop);
    el("div", "lcs-spinner", loading);
    const snippet = el("div", "lcs-snippet", pop);
    snippet.textContent = text.slice(0, 200) + (text.length > 200 ? "…" : "");
    textPopEl = pop;
    shadow.appendChild(pop);
  }

  function showTextPopupResult(rect, text, result) {
    if (!textPopEl) return;
    const cls = classify(result.score);
    textPopEl.innerHTML = "";

    const head = el("div", "lcs-card-head", textPopEl);
    const logo = el("img", "lcs-logo", head);
    logo.src = API_LOGO;
    el("div", "lcs-title", head).textContent = "Lá Chắn Số";

    textPopEl.appendChild(html(badgeHtml(cls.level)));

    const scoreRow = el("div", "lcs-score-row", textPopEl);
    scoreRow.innerHTML = ringHtml(result.score);
    const vWrap = el("div", null, scoreRow);
    const verdict = el("div", "lcs-verdict", vWrap);
    verdict.textContent = (result.score !== null && result.score !== undefined ? `${result.score}/100 · ` : "") + (result.verdict || cls.label);
    if (result.sensationalism && result.sensationalism !== "none") {
      el("div", "lcs-subtext", vWrap).textContent = "Giọng văn giật gân: " + (result.sensationalism === "high" ? "cao" : result.sensationalism === "medium" ? "trung bình" : "thấp");
    }

    if (result.patterns && result.patterns.length > 0) {
      const pList = el("div", "lcs-pattern-list", textPopEl);
      result.patterns.forEach((p) => {
        el("div", "lcs-pattern", pList).textContent = (p.name || p.pattern || "Dấu hiệu") + (p.severity === "high" ? " (nghiêm trọng)" : "");
      });
    }

    const snippet = el("div", "lcs-snippet", textPopEl);
    snippet.textContent = text.slice(0, 150) + (text.length > 150 ? "…" : "");

    el("div", "lcs-footnote", textPopEl).textContent = "Điểm do máy chủ Lá Chắn Số tính bằng AI";

    const closeBtn = el("button", "lcs-continue", textPopEl);
    closeBtn.textContent = "Đóng";
    closeBtn.addEventListener("click", removeTextPop);
  }

  function showTextPopupError(rect, text, msg) {
    if (!textPopEl) return;
    textPopEl.innerHTML = "";
    const head = el("div", "lcs-card-head", textPopEl);
    const logo = el("img", "lcs-logo", head);
    logo.src = API_LOGO;
    el("div", "lcs-title", head).textContent = "Lá Chắn Số";
    el("div", "lcs-error", textPopEl).textContent = "Không kiểm tra được: " + msg;
    const closeBtn = el("button", "lcs-continue", textPopEl);
    closeBtn.textContent = "Đóng";
    closeBtn.addEventListener("click", removeTextPop);
  }

  async function onBubbleClick(e) {
    e.stopPropagation();
    const text = selectedText();
    if (!text) { removeBubble(); return; }
    const rect = selectionRect();
    removeBubble();
    showTextPopupLoading(rect, text);
    try {
      const resp = await chrome.runtime.sendMessage({ type: "LCS_CHECK_TEXT", text });
      if (!resp || !resp.ok) throw new Error((resp && resp.error) || "Lỗi máy chủ");
      showTextPopupResult(rect, text, resp.result);
    } catch (err) {
      showTextPopupError(rect, text, err.message);
    }
  }

  // ---- Phát hiện bôi đen text ----
  let bubbleTimer = null;
  document.addEventListener("mouseup", () => {
    clearTimeout(bubbleTimer);
    const text = selectedText();
    if (!text) {
      bubbleTimer = setTimeout(() => { if (!textPopEl) removeBubble(); }, 300);
      return;
    }
    const rect = selectionRect();
    if (!rect) return;
    bubbleTimer = setTimeout(() => {
      if (textPopEl) return;
      showBubble(rect);
    }, 200);
  });

  document.addEventListener("click", (e) => {
    if (textPopEl && bubbleEl && !textPopEl.contains(e.target) && !bubbleEl.contains(e.target)) {
      removeTextPop();
      removeBubble();
    }
  });

  window.addEventListener("scroll", () => {
    removeBubble();
    if (textPopEl) removeTextPop();
  }, true);

  // ============ Nhận message từ background ============
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || !msg.type) return;
    if (msg.type === "LCS_URL_RESULT" && msg.result) {
      if (msg.result.url === lastCheckedUrl) return;
      lastCheckedUrl = msg.result.url;
      showOverlay(msg.result);
    }
    if (msg.type === "LCS_SHOW_URL_RESULT" && msg.result) {
      showOverlay(msg.result, { force: true });
    }
    if (msg.type === "LCS_CHECK_URL_CURRENT" && msg.url) {
      chrome.runtime.sendMessage({ type: "LCS_CHECK_URL", url: msg.url }, (resp) => {
        if (!chrome.runtime.lastError && resp && resp.ok && resp.result) {
          showOverlay(resp.result, { force: true });
        }
      });
    }
    if (msg.type === "LCS_SHOW_TEXT_RESULT" && msg.result) {
      const rect = { left: Math.max(20, window.innerWidth / 2 - 170), top: Math.max(20, window.innerHeight / 3) };
      showTextPopupLoading(rect, msg.selectionText || "");
      showTextPopupResult(rect, msg.selectionText || "", msg.result);
    }
  });

  // Auto-check trang hiện tại ngay khi content script được inject
  // (không phụ thuộc message từ background — đảm bảo luôn chạy)
  setTimeout(() => {
    try {
      const url = window.location.href;
      chrome.runtime.sendMessage({ type: "LCS_CHECK_URL", url }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (resp && resp.ok && !resp.skipped && resp.result) {
          lastCheckedUrl = url;
          showOverlay(resp.result);
        }
      });
    } catch {}
  }, 800);

  // Dọn dẹp khi rời trang
  window.addEventListener("unload", () => {
    if (hostEl && hostEl.parentNode) hostEl.parentNode.removeChild(hostEl);
  });
})();