// ============================================================
// Lá Chắn Số — Popup (bấm icon extension)
// - Kiểm tra trang hiện tại
// - Quản lý danh sách "không bao giờ kiểm tra web này nữa"
// ============================================================

const btnCheck = document.getElementById("btnCheckUrl");
const neverList = document.getElementById("neverList");

function getHostname(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function renderNeverList(never) {
  const hosts = Object.keys(never || {}).sort();
  neverList.innerHTML = "";
  if (hosts.length === 0) {
    const empty = document.createElement("div");
    empty.className = "p-never-empty";
    empty.textContent = "Chưa có web nào bị bỏ qua.";
    neverList.appendChild(empty);
    return;
  }
  hosts.forEach((host) => {
    const item = document.createElement("div");
    item.className = "p-never-item";

    const hostSpan = document.createElement("span");
    hostSpan.className = "p-never-host";
    hostSpan.textContent = host;

    const rmBtn = document.createElement("button");
    rmBtn.className = "p-never-remove";
    rmBtn.innerHTML = "&times;";
    rmBtn.title = "Gỡ khỏi danh sách";
    rmBtn.addEventListener("click", async () => {
      try {
        await chrome.runtime.sendMessage({ type: "LCS_REMOVE_NEVER_CHECK", hostname: host });
      } catch {}
      refreshNeverList();
    });

    item.appendChild(hostSpan);
    item.appendChild(rmBtn);
    neverList.appendChild(item);
  });
}

async function refreshNeverList() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: "LCS_GET_NEVER_LIST" });
    renderNeverList(resp && resp.neverCheck);
  } catch {
    renderNeverList({});
  }
}

btnCheck.addEventListener("click", async () => {
  btnCheck.disabled = true;
  btnCheck.textContent = "⏳ Đang kiểm tra...";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.startsWith("http")) {
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "LCS_CHECK_URL_CURRENT", url: tab.url });
      } catch {}
    }
    window.close();
  } finally {
    btnCheck.disabled = false;
  }
});

refreshNeverList();