// ============================================================
// Lá Chắn Số — Link Interceptor (Content Script)
// Bắt click trên thẻ <a> → preventDefault → overlay kiểm tra
// Shadow DOM (closed) để cách ly khỏi CSS của trang web
// ============================================================

(function () {
  if (window.__lcsInterceptorLoaded) return;
  window.__lcsInterceptorLoaded = true;

  const CSS = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .lcs-overlay {
    position: fixed; inset: 0; z-index: 2147483647;
    background: rgba(10, 10, 12, 0.75);
    backdrop-filter: blur(6px);
    display: flex; align-items: center; justify-content: center;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  }
  .lcs-modal {
    width: 92%; max-width: 480px; max-height: 85vh; overflow-y: auto;
    background: #ffffff; border-radius: 20px;
    box-shadow: 0 24px 80px rgba(0,0,0,0.35);
    padding: 28px; position: relative;
    animation: lcs-pop 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }
  @keyframes lcs-pop { from { transform: scale(0.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  .lcs-close {
    position: absolute; top: 12px; right: 12px; border: none;
    background: #f1f1f1; color: #444; width: 32px; height: 32px;
    border-radius: 50%; font-size: 16px; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background 0.15s;
  }
  .lcs-close:hover { background: #e0e0e0; }
  .lcs-header { display: flex; align-items: center; gap: 10px; }
  .lcs-logo { width: 36px; height: 36px; border-radius: 10px; }
  .lcs-title { font-size: 15px; font-weight: 700; color: #111; }
  .lcs-subtitle { font-size: 12px; color: #777; }
  .lcs-url-box {
    margin-top: 16px; padding: 12px 14px; background: #f7f7f8;
    border-radius: 12px; border: 1px solid #eee;
    font-family: monospace; font-size: 13px; color: #333;
    word-break: break-all;
  }
  .lcs-status { display: flex; align-items: center; gap: 10px; margin-top: 18px; }
  .lcs-status-icon { font-size: 28px; }
  .lcs-status-text { font-size: 20px; font-weight: 800; }
  .lcs-score { margin-left: auto; text-align: right; }
  .lcs-score-num { font-size: 30px; font-weight: 900; line-height: 1; }
  .lcs-score-label { font-size: 11px; color: #888; }
  .lcs-reasons { margin-top: 16px; list-style: none; display: flex; flex-direction: column; gap: 8px; }
  .lcs-reasons li {
    padding: 10px 12px; border-radius: 10px; font-size: 13px; line-height: 1.5;
    border: 1px solid #f0f0f0; background: #fafafa;
  }
  .lcs-reasons li::before { content: '• '; font-weight: 700; }
  .lcs-buttons { display: flex; gap: 10px; margin-top: 20px; }
  .lcs-btn {
    flex: 1; padding: 13px 16px; border-radius: 12px; border: none;
    font-size: 15px; font-weight: 700; cursor: pointer; transition: all 0.15s;
  }
  .lcs-btn:active { transform: scale(0.97); }
  .lcs-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .lcs-btn-primary { background: #111; color: #fff; }
  .lcs-btn-primary:hover { background: #000; }
  .lcs-btn-danger { background: #dc2626; color: #fff; }
  .lcs-btn-danger:hover { background: #b91c1c; }
  .lcs-btn-outline { background: #fff; color: #333; border: 1.5px solid #ddd; }
  .lcs-btn-outline:hover { background: #f5f5f5; }
  .lcs-btn-green { background: #16a34a; color: #fff; }
  .lcs-btn-green:hover { background: #15803d; }
  .lcs-btn-orange { background: #ea580c; color: #fff; }
  .lcs-btn-orange:hover { background: #c2410c; }
  .lcs-footer { margin-top: 16px; font-size: 11px; color: #aaa; text-align: center; }
  /* Loading spinner */
  .lcs-spinner {
    width: 44px; height: 44px; margin: 20px auto;
    border: 4px solid #f0f0f0; border-top-color: #ff8904;
    border-radius: 50%; animation: lcs-spin 0.8s linear infinite;
  }
  @keyframes lcs-spin { to { transform: rotate(360deg); } }
  .lcs-loading-center { text-align: center; padding: 20px 0; }
  .lcs-loading-text { color: #666; font-size: 14px; margin-top: 12px; }
  /* Safe auto-countdown */
  .lcs-countdown { font-size: 12px; color: #888; text-align: center; margin-top: 10px; }
  /* State colors */
  .lcs-s-danger { color: #dc2626; }
  .lcs-s-suspicious { color: #ea580c; }
  .lcs-s-verify { color: #d97706; }
  .lcs-s-safe { color: #16a34a; }
  .lcs-s-unknown { color: #6b7280; }
  `;

  const STATE_META = {
    danger: { icon: "🚫", text: "NGUY HIỂM", cls: "lcs-s-danger", desc: "Không truy cập trang này!" },
    suspicious: { icon: "⚠️", text: "ĐÁNG NGỜ", cls: "lcs-s-suspicious", desc: "Cần thận trọng trước khi tiếp tục." },
    verify: { icon: "🟡", text: "CẦN XÁC MINH", cls: "lcs-s-verify", desc: "Chưa đủ dữ liệu để khẳng định an toàn." },
    safe: { icon: "✅", text: "AN TOÀN", cls: "lcs-s-safe", desc: "Trang này được đánh giá an toàn." },
    unknown: { icon: "❓", text: "KHÔNG RÕ", cls: "lcs-s-unknown", desc: "Không xác định được mức độ an toàn." }
  };

  function hostFromUrl(url) {
    try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return url; }
  }

  // ============ CHECK FLOW ============
  function checkUrl(url, triggerEl) {
    // Không chặn các link nội bộ / javascript / mailto
    if (!url || url.startsWith("javascript:") || url.startsWith("mailto:") ||
        url.startsWith("tel:") || url.startsWith("data:")) return;

    // Overlay host
    const host = document.createElement("div");
    host.id = "lcs-interceptor-host";
    const shadow = host.attachShadow({ mode: "closed" });
    document.documentElement.appendChild(host);

    // Render loading state
    const render = (html) => { shadow.innerHTML = `<style>${CSS}</style>${html}`; };
    render(`
      <div class="lcs-overlay">
        <div class="lcs-modal">
          <div class="lcs-loading-center">
            <div class="lcs-spinner"></div>
            <div class="lcs-loading-text">Đang kiểm tra an toàn...</div>
          </div>
          <div class="lcs-url-box">${escapeHtml(url)}</div>
        </div>
      </div>
    `);

    // Gửi message sang service worker
    let responded = false;
    const timeout = setTimeout(() => {
      if (responded) return;
      responded = true;
      renderResult(shadow, { state: "unknown", R: 50, reasons: ["Kiểm tra quá lâu, đã hủy."] }, url);
    }, 20000);

    try {
      chrome.runtime.sendMessage({ type: "CHECK_URL", url }, (res) => {
        if (chrome.runtime.lastError) {
          clearTimeout(timeout);
          if (responded) return;
          responded = true;
          renderResult(shadow, { state: "unknown", R: 50, reasons: [chrome.runtime.lastError.message || "Lỗi kết nối extension."] }, url);
          return;
        }
        clearTimeout(timeout);
        if (responded) return;
        responded = true;
        renderResult(shadow, res || { state: "unknown", R: 50, reasons: ["Không có phản hồi."] }, url);
      });
    } catch {
      clearTimeout(timeout);
      if (responded) return;
      responded = true;
      renderResult(shadow, { state: "unknown", R: 50, reasons: ["Lỗi khởi tạo."] }, url);
    }

    // Đóng overlay khi bấm ESC hoặc ra ngoài
    const escHandler = (e) => {
      if (e.key === "Escape") { cleanup(); }
    };
    const cleanup = () => {
      document.removeEventListener("keydown", escHandler, true);
      if (host && host.parentNode) host.parentNode.removeChild(host);
    };
    document.addEventListener("keydown", escHandler, true);
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }

  // ============ RENDER RESULT ============
  function renderResult(shadow, res, url) {
    const meta = STATE_META[res.state] || STATE_META.unknown;
    const score = typeof res.R === "number" ? res.R : 50;
    const reasons = Array.isArray(res.reasons) && res.reasons.length
      ? res.reasons
      : [meta.desc];

    let buttons = "";
    if (res.state === "danger") {
      buttons = `
        <button class="lcs-btn lcs-btn-danger" id="lcs-exit">🚪 Thoát ngay</button>
        <button class="lcs-btn lcs-btn-outline" id="lcs-continue">Vẫn truy cập</button>
      `;
    } else if (res.state === "suspicious" || res.state === "verify") {
      buttons = `
        <button class="lcs-btn lcs-btn-outline" id="lcs-back">← Quay lại</button>
        <button class="lcs-btn lcs-btn-orange" id="lcs-continue" disabled>Đang chờ 3s...</button>
      `;
    } else {
      buttons = `
        <button class="lcs-btn lcs-btn-green" id="lcs-continue">Tiếp tục truy cập →</button>
      `;
    }

    const html = `
      <div class="lcs-overlay">
        <div class="lcs-modal">
          <button class="lcs-close" id="lcs-close">✕</button>
          <div class="lcs-header">
            <img class="lcs-logo" src="${chrome.runtime.getURL("icons/icon48.png")}" alt="Lá Chắn Số"/>
            <div>
              <div class="lcs-title">Lá Chắn Số</div>
              <div class="lcs-subtitle">Kiểm tra an toàn website</div>
            </div>
          </div>
          <div class="lcs-url-box">${escapeHtml(url)}</div>
          <div class="lcs-status">
            <span class="lcs-status-icon">${meta.icon}</span>
            <div>
              <div class="lcs-status-text ${meta.cls}">${meta.text}</div>
              <div style="font-size:12px;color:#888">${meta.desc}</div>
            </div>
            <div class="lcs-score">
              <div class="lcs-score-num ${meta.cls}">${score}</div>
              <div class="lcs-score-label">/100 điểm</div>
            </div>
          </div>
          <ul class="lcs-reasons">${reasons.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>
          <div class="lcs-buttons">${buttons}</div>
          <div class="lcs-footer">Kết quả từ hệ thống Lá Chắn Số · Không chịu trách nhiệm khi tự ý truy cập</div>
        </div>
      </div>
    `;
    shadow.innerHTML = `<style>${CSS}</style>${html}`;

    const closeBtn = shadow.getElementById("lcs-close");
    if (closeBtn) closeBtn.onclick = () => cleanup();

    const backBtn = shadow.getElementById("lcs-back");
    if (backBtn) backBtn.onclick = () => cleanup();

    const exitBtn = shadow.getElementById("lcs-exit");
    if (exitBtn) exitBtn.onclick = () => {
      try { history.back(); } catch {}
      cleanup();
    };

    const continueBtn = shadow.getElementById("lcs-continue");
    if (continueBtn) {
      if (res.state === "suspicious" || res.state === "verify") {
        let count = 3;
        const timer = setInterval(() => {
          count -= 1;
          if (count <= 0) {
            clearInterval(timer);
            continueBtn.disabled = false;
            continueBtn.textContent = "Tiếp tục truy cập →";
          } else {
            continueBtn.textContent = `Đang chờ ${count}s...`;
          }
        }, 1000);
        continueBtn.onclick = () => { cleanup(); window.location.href = url; };
      } else {
        continueBtn.onclick = () => { cleanup(); window.location.href = url; };
        if (res.state === "safe") {
          setTimeout(() => {
            const h = shadow.host;
            if (h && h.parentNode) {
              window.location.href = url;
            }
          }, 1200);
        }
      }
    }

    // Dọn khi thay đổi trang
    function cleanup() {
      const host = shadow.host;
      if (host && host.parentNode) host.parentNode.removeChild(host);
    }
  }

  // ============ CLICK INTERCEPTOR (capture phase) ============
  document.addEventListener("click", (e) => {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    const link = e.target.closest ? e.target.closest("a[href]") : null;
    if (!link) return;

    const href = link.href;
    if (!href || href.startsWith("javascript:") || href.startsWith("mailto:") ||
        href.startsWith("tel:") || href.startsWith("data:")) return;

    const url = new URL(href);
    const currentUrl = new URL(window.location.href);
    if (url.origin === currentUrl.origin && url.pathname === currentUrl.pathname) {
      // Cùng trang (anchor) → không chặn
      if (url.hash) return;
    }
    // Liên kết nội bộ cùng origin → không chặn (vẫn an toàn vì cùng site)
    if (url.origin === currentUrl.origin) return;

    // Chặn navigation tới site khác
    e.preventDefault();
    e.stopPropagation();
    checkUrl(href, link);
  }, true);

  // ============ NHẬN MESSAGE từ service worker (context menu) ============
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "CHECK_URL" && msg.url) {
      checkUrl(msg.url);
      sendResponse({ ok: true });
    }
    if (msg && msg.type === "ANALYZE_TEXT" && msg.text) {
      // Widget xử lý message này
      sendResponse({ ok: true });
    }
  });
})();
