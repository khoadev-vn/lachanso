// ============================================================
// Lá Chắn Số — Floating Assistant Widget (Content Script)
// Icon nổi draggable → user select text → click → phân tích
// Shadow DOM (closed) cách ly khỏi CSS trang web
// ============================================================

(function () {
  if (window.__lcsWidgetLoaded) return;
  window.__lcsWidgetLoaded = true;

  const CSS = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .lcs-w-float {
    position: fixed; z-index: 2147483646; width: 46px; height: 46px;
    border-radius: 50%; cursor: grab; user-select: none;
    box-shadow: 0 4px 20px rgba(0,0,0,0.25);
    display: flex; align-items: center; justify-content: center;
    transition: transform 0.15s, box-shadow 0.15s;
    background: linear-gradient(135deg, #ff8904, #ff5c1a);
    border: 2.5px solid #fff;
  }
  .lcs-w-float:hover { transform: scale(1.08); box-shadow: 0 6px 28px rgba(255,137,4,0.5); }
  .lcs-w-float:active { cursor: grabbing; }
  .lcs-w-float img { width: 28px; height: 28px; border-radius: 50%; pointer-events: none; }
  .lcs-w-pop {
    position: fixed; z-index: 2147483647; width: 340px; max-width: 90vw;
    background: #ffffff; border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    border: 1px solid #eee; overflow: hidden;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    animation: lcs-w-pop 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  }
  @keyframes lcs-w-pop { from { transform: translateY(8px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  .lcs-w-head {
    display: flex; align-items: center; gap: 8px; padding: 12px 14px;
    background: linear-gradient(135deg, #ff8904, #ff5c1a); color: #fff;
  }
  .lcs-w-head img { width: 22px; height: 22px; border-radius: 50%; }
  .lcs-w-head-title { font-size: 13px; font-weight: 700; flex: 1; }
  .lcs-w-close {
    border: none; background: rgba(255,255,255,0.2); color: #fff;
    width: 24px; height: 24px; border-radius: 50%; cursor: pointer;
    font-size: 13px; line-height: 1; display: flex; align-items: center; justify-content: center;
  }
  .lcs-w-close:hover { background: rgba(255,255,255,0.35); }
  .lcs-w-body { padding: 14px; max-height: 380px; overflow-y: auto; }
  .lcs-w-hint { font-size: 13px; color: #666; line-height: 1.6; }
  .lcs-w-loading { text-align: center; padding: 16px 0; }
  .lcs-w-spinner {
    width: 36px; height: 36px; margin: 0 auto;
    border: 3.5px solid #f0f0f0; border-top-color: #ff8904;
    border-radius: 50%; animation: lcs-w-spin 0.8s linear infinite;
  }
  @keyframes lcs-w-spin { to { transform: rotate(360deg); } }
  .lcs-w-loading-text { font-size: 12px; color: #888; margin-top: 10px; }
  .lcs-w-verdict {
    display: flex; align-items: center; gap: 10px; padding: 12px;
    border-radius: 12px; border: 1.5px solid #eee; margin-bottom: 10px;
  }
  .lcs-w-v-icon { font-size: 26px; }
  .lcs-w-v-text { font-size: 16px; font-weight: 800; }
  .lcs-w-v-score { margin-left: auto; font-size: 22px; font-weight: 900; }
  .lcs-w-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
  .lcs-w-tag {
    font-size: 11px; font-weight: 600; padding: 4px 10px; border-radius: 20px;
    background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;
  }
  .lcs-w-tag.ok { background: #f0fdf4; color: #16a34a; border-color: #bbf7d0; }
  .lcs-w-tag.warn { background: #fffbeb; color: #d97706; border-color: #fde68a; }
  .lcs-w-reasons { list-style: none; display: flex; flex-direction: column; gap: 6px; }
  .lcs-w-reasons li {
    font-size: 12px; color: #444; padding: 8px 10px; background: #fafafa;
    border-radius: 8px; border: 1px solid #f0f0f0; line-height: 1.5;
  }
  .lcs-w-reasons li::before { content: '• '; font-weight: 700; }
  .lcs-w-foot { padding: 10px 14px; border-top: 1px solid #f0f0f0; font-size: 10px; color: #aaa; text-align: center; }
  `;

  // ============ TẠO SHADOW DOM ============
  const host = document.createElement("div");
  host.id = "lcs-widget-host";
  const shadow = host.attachShadow({ mode: "closed" });
  (document.documentElement || document.body).appendChild(host);

  shadow.innerHTML = `
    <style>${CSS}</style>
    <div class="lcs-w-float" id="lcs-w-float" title="Lá Chắn Số — chọn text rồi bấm để phân tích">
      <img src="${chrome.runtime.getURL("icons/icon48.png")}" alt="Lá Chắn Số"/>
    </div>
    <div class="lcs-w-pop" id="lcs-w-pop" style="display:none"></div>
  `;

  const floatEl = shadow.getElementById("lcs-w-float");
  const popEl = shadow.getElementById("lcs-w-pop");

  // Vị trí mặc định: góc phải dưới
  const DEFAULT_X = window.innerWidth - 70;
  const DEFAULT_Y = window.innerHeight - 70;
  floatEl.style.right = "16px";
  floatEl.style.bottom = "16px";

  // ============ KÉO THẢ ============
  let isDragging = false;
  let dragOffset = null;

  floatEl.addEventListener("mousedown", (e) => {
    if (e.button !== 0) return;
    isDragging = false;
    dragOffset = { x: e.clientX, y: e.clientY };
    const moveHandler = (ev) => {
      if (!dragOffset) return;
      const dx = ev.clientX - dragOffset.x;
      const dy = ev.clientY - dragOffset.y;
      if (Math.abs(dx) > 4 || Math.abs(dy) > 4) isDragging = true;
      if (isDragging) {
        floatEl.style.left = (ev.clientX - 23) + "px";
        floatEl.style.top = (ev.clientY - 23) + "px";
        floatEl.style.right = "auto";
        floatEl.style.bottom = "auto";
      }
    };
    const upHandler = () => {
      document.removeEventListener("mousemove", moveHandler);
      document.removeEventListener("mouseup", upHandler);
    };
    document.addEventListener("mousemove", moveHandler);
    document.addEventListener("mouseup", upHandler);
  });

  // ============ CLICK: phân tích text được select ============
  floatEl.addEventListener("click", (e) => {
    e.stopPropagation();
    if (isDragging) { isDragging = false; return; }

    const sel = window.getSelection();
    const text = sel && sel.toString() ? sel.toString().trim() : "";

    if (!text) {
      showPopupHint("🖱️ Bôi đen đoạn văn bản nghi vấn (tin nhắn, bài viết, mô tả công việc...), sau đó bấm vào icon để phân tích.");
      return;
    }
    if (text.length < 10) {
      showPopupHint("Đoạn văn bản quá ngắn. Hãy chọn đầy đủ nội dung cần kiểm tra.");
      return;
    }

    // Loading state
    showPopup(`
      <div class="lcs-w-head">
        <img src="${chrome.runtime.getURL("icons/icon48.png")}"/>
        <span class="lcs-w-head-title">Lá Chắn Số — Đang phân tích</span>
        <button class="lcs-w-close">✕</button>
      </div>
      <div class="lcs-w-body">
        <div class="lcs-w-loading">
          <div class="lcs-w-spinner"></div>
          <div class="lcs-w-loading-text">Đang phân tích dấu hiệu lừa đảo...</div>
        </div>
        <div style="margin-top:10px;font-size:11px;color:#999;line-height:1.5;word-break:break-word;border-left:3px solid #eee;padding-left:8px">${escapeHtml(text.slice(0, 180))}${text.length > 180 ? "…" : ""}</div>
      </div>
      <div class="lcs-w-foot">Lá Chắn Số · Phân tích văn bản nghi vấn</div>
    `);

    chrome.runtime.sendMessage({ type: "ANALYZE_TEXT", text }, (res) => {
      if (chrome.runtime.lastError) {
        showResult({ verdict: { status: "unknown", score: null, summary: "Lỗi kết nối extension." } }, text);
        return;
      }
      showResult(res || { verdict: { status: "unknown" } }, text);
    });
  });

  // ============ RENDER KẾT QUẢ ============
  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[c]);
  }

  function showPopup(inner) {
    popEl.style.display = "block";
    const rect = floatEl.getBoundingClientRect();
    let left = rect.left - 340;
    let top = rect.top - 60;
    if (left < 8) left = rect.right + 8;
    if (top < 8) top = 8;
    if (left + 340 > window.innerWidth) left = window.innerWidth - 348;
    if (top + 420 > window.innerHeight) top = window.innerHeight - 428;
    popEl.style.left = left + "px";
    popEl.style.top = top + "px";
    popEl.innerHTML = inner;

    const close = popEl.querySelector(".lcs-w-close");
    if (close) close.addEventListener("click", () => { popEl.style.display = "none"; });
  }

  function showPopupHint(message) {
    showPopup(`
      <div class="lcs-w-head">
        <img src="${chrome.runtime.getURL("icons/icon48.png")}"/>
        <span class="lcs-w-head-title">Lá Chắn Số</span>
        <button class="lcs-w-close">✕</button>
      </div>
      <div class="lcs-w-body">
        <div class="lcs-w-hint">${escapeHtml(message)}</div>
      </div>
      <div class="lcs-w-foot">Chọn văn bản → bấm icon để phân tích</div>
    `);
  }

  function showResult(data, text) {
    const verdict = (data && data.verdict) || {};
    const status = verdict.status || (data.state) || "unknown";

    const META = {
      danger: { icon: "🚫", text: "NGUY HIỂM", color: "#dc2626", bg: "#fef2f2", border: "#fecaca", score: verdict.score != null ? verdict.score : 85 },
      suspicious: { icon: "⚠️", text: "ĐÁNG NGỜ", color: "#ea580c", bg: "#fff7ed", border: "#fed7aa", score: verdict.score != null ? verdict.score : 60 },
      verify: { icon: "🟡", text: "CẦN XÁC MINH", color: "#d97706", bg: "#fffbeb", border: "#fde68a", score: verdict.score != null ? verdict.score : 50 },
      safe: { icon: "✅", text: "AN TOÀN", color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0", score: verdict.score != null ? verdict.score : 20 },
      unknown: { icon: "❓", text: "KHÔNG RÕ", color: "#6b7280", bg: "#f9fafb", border: "#e5e7eb", score: verdict.score != null ? verdict.score : 50 }
    };
    const m = META[status] || META.unknown;

    // Tín hiệu / lý do
    const reasons = [];
    if (Array.isArray(verdict.reasons)) reasons.push(...verdict.reasons);
    if (Array.isArray(verdict.signals)) reasons.push(...verdict.signals.map((s) => (typeof s === "string" ? s : s.reason || s.type)));
    if (Array.isArray(data && data.reasons)) reasons.push(...data.reasons);
    const unique = [...new Set(reasons.filter(Boolean))];

    const summary = verdict.summary || (typeof verdict.detail === "string" ? verdict.detail : null);

    const tags = [];
    if (Array.isArray(verdict.signals) && verdict.signals.length) {
      verdict.signals.slice(0, 4).forEach((s) => {
        const type = (typeof s === "string" ? s : (s.type || s.reason)) || "";
        const sev = (s && s.severity) || "warn";
        tags.push(`<span class="lcs-w-tag ${sev === "high" ? "" : sev === "none" ? "ok" : "warn"}">${escapeHtml(String(type))}</span>`);
      });
    }

    const reasonsHtml = unique.length
      ? `<ul class="lcs-w-reasons">${unique.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>`
      : `<div style="font-size:12px;color:#666;line-height:1.6">${escapeHtml(summary || "Không có lý do cụ thể.")}</div>`;

    showPopup(`
      <div class="lcs-w-head">
        <img src="${chrome.runtime.getURL("icons/icon48.png")}"/>
        <span class="lcs-w-head-title">Kết quả phân tích</span>
        <button class="lcs-w-close">✕</button>
      </div>
      <div class="lcs-w-body">
        <div class="lcs-w-verdict" style="background:${m.bg};border-color:${m.border}">
          <span class="lcs-w-v-icon">${m.icon}</span>
          <span class="lcs-w-v-text" style="color:${m.color}">${m.text}</span>
          <span class="lcs-w-v-score" style="color:${m.color}">${m.score}</span>
        </div>
        ${summary ? `<div style="font-size:12px;color:#555;line-height:1.6;margin-bottom:10px">${escapeHtml(summary)}</div>` : ""}
        ${tags.length ? `<div class="lcs-w-tags">${tags.join("")}</div>` : ""}
        ${reasonsHtml}
      </div>
      <div class="lcs-w-foot">Lá Chắn Số · ${escapeHtml(text.slice(0, 40))}${text.length > 40 ? "…" : ""}</div>
    `);
  }

  // ============ Nhận message từ SW (context menu selection) ============
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "ANALYZE_TEXT" && msg.text) {
      chrome.runtime.sendMessage({ type: "ANALYZE_TEXT", text: msg.text }, (res) => {
        showResult(res || { verdict: { status: "unknown" } }, msg.text);
      });
      sendResponse({ ok: true });
    }
  });
})();
