// Lá Chắn Số — Popup logic
const API_BASE = "https://lachansovn.com";

const stateMeta = {
  danger: { icon: "🚫", text: "NGUY HIỂM", color: "#dc2626", bg: "#fef2f2", border: "#fecaca", btnClass: "result-btn-red", btnText: "Đừng truy cập" },
  suspicious: { icon: "⚠️", text: "ĐÁNG NGỜ", color: "#ea580c", bg: "#fff7ed", border: "#fed7aa", btnClass: "result-btn-orange", btnText: "Thận trọng" },
  verify: { icon: "🟡", text: "CẦN XÁC MINH", color: "#d97706", bg: "#fffbeb", border: "#fde68a", btnClass: "result-btn-orange", btnText: "Xác minh thêm" },
  safe: { icon: "✅", text: "AN TOÀN", color: "#16a34a", bg: "#f0fdf4", border: "#bbf7d0", btnClass: "result-btn-green", btnText: "An toàn" },
  unknown: { icon: "❓", text: "KHÔNG RÕ", color: "#6b7280", bg: "#f9fafb", border: "#e5e7eb", btnClass: "result-btn-gray", btnText: "Không chắc" }
};

const el = {
  input: document.getElementById("url-input"),
  btn: document.getElementById("url-btn"),
  result: document.getElementById("result"),
  loading: document.getElementById("result-loading"),
  content: document.getElementById("result-content"),
  scamCount: document.getElementById("scam-count"),
  badge: document.getElementById("status-badge"),
  btnCurrent: document.getElementById("quick-current"),
  btnScam: document.getElementById("quick-scam")
};

// ============ Khởi tạo: hiển thị số domain scam ============
function init() {
  try {
    chrome.runtime.sendMessage({ type: "GET_SCAM_STATS" }, (res) => {
      if (res && typeof res.scamDomainsCount === "number") {
        el.scamCount.textContent = `Bảo vệ: ${res.scamDomainsCount.toLocaleString("vi-VN")} domain lừa đảo`;
      }
    });
  } catch {}
}

// ============ Check URL ============
async function checkUrl(url) {
  el.result.style.display = "block";
  el.loading.style.display = "block";
  el.content.innerHTML = "";

  try {
    const res = await chrome.runtime.sendMessage({ type: "CHECK_URL", url });
    renderResult(res || { state: "unknown", R: 50, reasons: ["Không có phản hồi."] }, url);
  } catch (err) {
    renderResult({ state: "unknown", R: 50, reasons: [err.message || "Lỗi kiểm tra."] }, url);
  } finally {
    el.loading.style.display = "none";
  }
}

function renderResult(res, url) {
  const state = res.state || "unknown";
  const m = stateMeta[state] || stateMeta.unknown;
  const score = typeof res.R === "number" ? res.R : 50;
  const reasons = Array.isArray(res.reasons) && res.reasons.length ? res.reasons : ["Không có lý do chi tiết."];

  el.content.innerHTML = `
    <div class="result-box" style="background:${m.bg};border-color:${m.border}">
      <div class="result-top">
        <span class="result-icon">${m.icon}</span>
        <span class="result-verdict" style="color:${m.color}">${m.text}</span>
        <div class="result-score">
          <div class="result-score-num" style="color:${m.color}">${score}</div>
          <div class="result-score-label">/100 điểm</div>
        </div>
      </div>
      <div class="result-url">${escapeHtml(url || "")}</div>
      <ul class="result-reasons">${reasons.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>
      <div class="result-actions">
        <button class="result-btn ${m.btnClass}" id="res-open">${m.btnText} →</button>
      </div>
    </div>
  `;

  if (state === "danger") {
    el.content.querySelector("#res-open").textContent = "Báo lỗi cho Lá Chắn Số";
    el.content.querySelector("#res-open").addEventListener("click", () => {
      chrome.tabs.create({ url: "https://lachansovn.com/report" });
    });
  } else {
    el.content.querySelector("#res-open").addEventListener("click", () => {
      if (url) chrome.tabs.create({ url });
    });
  }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[c]);
}

// ============ Quick actions ============
async function checkCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.url && tab.url.startsWith("http")) {
    el.input.value = tab.url;
    checkUrl(tab.url);
  } else {
    renderResult({ state: "unknown", R: 50, reasons: ["Trang này không kiểm tra được (nội bộ trình duyệt)."] }, tab && tab.url);
  }
}

async function showScamList() {
  el.result.style.display = "block";
  el.loading.style.display = "none";
  try {
    const res = await fetch(`${API_BASE}/api/scam-domains?limit=15`);
    const data = await res.json();
    const items = Array.isArray(data) ? data : [];
    const html = items.length
      ? items.map((d) => {
          const domain = typeof d === "string" ? d : d.domain;
          const src = typeof d === "string" ? "feed" : d.source;
          const date = typeof d === "string" ? "" : (d.discoveredAt || "");
          return `<div class="scam-item">
            <span class="scam-domain">${escapeHtml(domain)}</span>
            <span class="scam-source">${escapeHtml(src)}${date ? " · " + String(date).slice(0, 10) : ""}</span>
          </div>`;
        }).join("")
      : `<div style="font-size:12px;color:#888;padding:8px">Không có dữ liệu.</div>`;
    el.content.innerHTML = `<div class="scam-list">${html}</div>`;
  } catch (e) {
    el.content.innerHTML = `<div style="font-size:12px;color:#888;padding:8px">Không tải được danh sách.</div>`;
  }
}

// ============ Events ============
el.btn.addEventListener("click", () => {
  const url = el.input.value.trim();
  if (url) checkUrl(url);
});

el.input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    const url = el.input.value.trim();
    if (url) checkUrl(url);
  }
});

el.btnCurrent.addEventListener("click", checkCurrentTab);
el.btnScam.addEventListener("click", showScamList);

init();