// ============================================================
// Lá Chắn Số — Service Worker (Manifest V3)
// - Sync scam-domains vào chrome.storage.local mỗi 30 phút
// - Nhận message từ content scripts (CHECK_URL / ANALYZE_TEXT)
// - Context menu: kiểm tra link bằng chuột phải
// ============================================================

const API_BASE = "https://lachansovn.com";
const SYNC_ALARM = "lcs-sync-scam-domains";
const SYNC_INTERVAL_MINUTES = 30;

// ============ ON INSTALL: sync + alarm + context menu ============
chrome.runtime.onInstalled.addListener(() => {
  syncScamDomains();
  chrome.alarms.create(SYNC_ALARM, { periodInMinutes: SYNC_INTERVAL_MINUTES });

  chrome.contextMenus.create({
    id: "lcs-check-link",
    title: "Kiểm tra link với Lá Chắn Số",
    contexts: ["link"]
  });
  chrome.contextMenus.create({
    id: "lcs-check-selection",
    title: "Phân tích đoạn văn bản với Lá Chắn Số",
    contexts: ["selection"]
  });

  updateBadge();
});

// ============ ALARM: sync định kỳ ============
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === SYNC_ALARM) {
    syncScamDomains();
  }
});

// ============ SYNC: tải scam-domains vào storage ============
async function syncScamDomains() {
  try {
    const res = await fetch(`${API_BASE}/api/scam-domains?limit=200`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const domains = Array.isArray(data) ? data : [];
    const list = domains
      .map((d) => (typeof d === "string" ? d : d.domain))
      .filter(Boolean)
      .map((s) => String(s).toLowerCase().replace(/^https?:\/\//, "").replace(/\/+$/, ""));

    await chrome.storage.local.set({
      scamDomains: list,
      scamDomainsUpdatedAt: Date.now(),
      scamDomainsCount: list.length
    });
    console.log(`[LCS] Synced ${list.length} scam domains`);
    updateBadge();
  } catch (e) {
    console.error("[LCS] Sync failed:", e.message);
  }
}

// ============ BADGE: số domain scam trong cache ============
async function updateBadge() {
  try {
    const { scamDomainsCount = 0 } = await chrome.storage.local.get("scamDomainsCount");
    if (scamDomainsCount > 0) {
      await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" });
      await chrome.action.setBadgeText({ text: String(Math.min(scamDomainsCount, 999)) });
    } else {
      await chrome.action.setBadgeText({ text: "" });
    }
  } catch { /* ignore */ }
}

// ============ MESSAGE HANDLER: từ content scripts ============
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "CHECK_URL") {
    handleCheckUrl(msg.url)
      .then((result) => sendResponse({ success: true, ...result }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }

  if (msg.type === "ANALYZE_TEXT") {
    handleAnalyzeText(msg.text)
      .then((result) => sendResponse({ success: true, ...result }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (msg.type === "GET_SCAM_STATS") {
    getScamStats().then(sendResponse);
    return true;
  }
});

// ============ CHECK URL: local trước, API sau ============
async function handleCheckUrl(url) {
  let hostname = "";
  try {
    hostname = new URL(url).hostname;
  } catch {
    return { state: "unknown", R: 50, C: 0.5, reasons: ["URL không hợp lệ."], hostname };
  }
  const cleanHost = hostname.toLowerCase().replace(/^www\./, "");

  // Lớp 1: check local cache (< 1ms)
  const { scamDomains = [] } = await chrome.storage.local.get("scamDomains");
  const exact = scamDomains.find((d) => {
    const clean = String(d).toLowerCase();
    return clean === cleanHost || clean === hostname.toLowerCase();
  });
  if (exact) {
    return {
      state: "danger",
      R: 100,
      C: 1,
      hostname,
      reasons: ["Domain có trong danh sách lừa đảo của Lá Chắn Số."],
      fromLocal: true
    };
  }

  // Lớp 2: gọi API web-verify
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(`${API_BASE}/api/v2/web-verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const data = await res.json();
    if (data && data.state) {
      return { ...data, hostname };
    }
    return { state: "unknown", R: 50, C: 0.5, hostname, reasons: ["Không xác định được mức độ."] };
  } catch (e) {
    clearTimeout(timeout);
    console.error("[LCS] Web-verify failed:", e.message);
    return { state: "unknown", R: 50, C: 0.5, hostname, reasons: ["Không kết nối được máy chủ."] };
  }
}

// ============ ANALYZE TEXT: gọi API verify-message ============
async function handleAnalyzeText(text) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(`${API_BASE}/api/verify-message`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const data = await res.json();
    return data && typeof data === "object" ? data : { verdict: { status: "unknown" } };
  } catch (e) {
    clearTimeout(timeout);
    console.error("[LCS] Text analysis failed:", e.message);
    return { verdict: { status: "unknown", summary: "Không kết nối được máy chủ." } };
  }
}

// ============ GET SCAM STATS: thống kê ============
async function getScamStats() {
  try {
    const { scamDomainsCount = 0, scamDomainsUpdatedAt = null } = await chrome.storage.local.get([
      "scamDomainsCount",
      "scamDomainsUpdatedAt"
    ]);
    return { scamDomainsCount, scamDomainsUpdatedAt };
  } catch {
    return { scamDomainsCount: 0, scamDomainsUpdatedAt: null };
  }
}

// ============ CONTEXT MENU ============
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "lcs-check-link" && info.linkUrl && tab && tab.id != null) {
    chrome.tabs.sendMessage(tab.id, { type: "CHECK_URL", url: info.linkUrl }).catch(() => {});
  }
  if (info.menuItemId === "lcs-check-selection" && info.selectionText && tab && tab.id != null) {
    chrome.tabs.sendMessage(tab.id, { type: "ANALYZE_TEXT", text: info.selectionText }).catch(() => {});
  }
});
